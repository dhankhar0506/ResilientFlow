

// import type { ReactNode } from "react";
// import { alpha } from "@mui/material/styles";
// import { Box, Button, Chip, Paper, Stack, Typography } from "@mui/material";

// import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
// import ArrowBackRoundedIcon from "@mui/icons-material/ArrowBackRounded";
// import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";

// export const MONO = "ui-monospace, SFMono-Regular, Menlo, monospace";


// export const RADIUS = { card: "16px", inner: "10px", pill: 99 } as const;
// export const PAGE_MAX_WIDTH = 1280;


// export const cardSx = {
//   p: { xs: 1.25, sm: 1.75 },
//   borderRadius: RADIUS.card,
//   borderColor: "divider",
//   bgcolor: "background.paper",
// } as const;

// export const accentCardSx = (color = "primary.main") =>
//   ({ ...cardSx, borderTop: "3px solid", borderTopColor: color }) as const;


// export const insetSx = {
//   p: 1,
//   borderRadius: RADIUS.inner,
//   bgcolor: "action.hover",
// } as const;


// export const nodeSx = (borderColor = "divider", bgcolor = "background.paper") =>
//   ({
//     p: 0.9,
//     borderRadius: RADIUS.inner,
//     border: "1.5px solid",
//     borderColor,
//     bgcolor,
//     textAlign: "center",
//   }) as const;


// export const labelSx = {
//   typography: "caption",
//   fontWeight: 700,
//   color: "text.secondary",
//   textTransform: "uppercase",
//   letterSpacing: 0.6,
// } as const;

// export const monoSx = { fontFamily: MONO, fontWeight: 700 } as const;


// export function LessonPage({ children }: { children: ReactNode }) {
//   return (
//     <Stack spacing={1.5} sx={{ width: "100%", maxWidth: PAGE_MAX_WIDTH, mx: "auto" }}>
//       {children}
//     </Stack>
//   );
// }


// export function LessonBody({
//   visual,
//   children,
// }: {
//   visual: ReactNode;
//   children: ReactNode;
// }) {
//   return (
//     <Box
//       sx={{
//         display: "grid",
//         gap: 1.5,
//         alignItems: "start",
//         gridTemplateColumns: { xs: "minmax(0, 1fr)", lg: "minmax(0, 1.05fr) minmax(0, 1fr)" },
//       }}
//     >
//       <Box sx={{ minWidth: 0 }}>{visual}</Box>
//       <Box sx={{ minWidth: 0 }}>{children}</Box>
//     </Box>
//   );
// }

// export function LessonHeader({
//   eyebrow,
//   title,
//   subtitle,
// }: {
//   eyebrow: string;
//   title: string;
//   subtitle: string;
// }) {
//   return (
//     <Box>
//       {eyebrow && (
//         <Typography variant="subtitle2" sx={{ color: "primary.main", mb: 0.2 }}>
//           {eyebrow}
//         </Typography>
//       )}
//       <Typography component="h1" variant="h1" sx={{ letterSpacing: "-0.3px", mb: 0.3 }}>
//         {title}
//       </Typography>
//       <Typography variant="body1" sx={{ color: "text.secondary" }}>
//         {subtitle}
//       </Typography>
//     </Box>
//   );
// }

// export function LessonStatus({
//   availableLabel,
//   right,
// }: {
//   availableLabel: string;
//   right?: ReactNode;
// }) {
//   return (
//     <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1}>
//       <Chip label={availableLabel} size="small" sx={{ bgcolor: "success.main", color: "#fff", fontWeight: 800 }} />
//       {right && (
//         <Typography variant="body2" sx={{ color: "text.secondary", fontWeight: 700 }}>
//           {right}
//         </Typography>
//       )}
//     </Stack>
//   );
// }


// export function StepBar({
//   total,
//   index,
//   onSelect,
//   label,
//   colorFor,
// }: {
//   total: number;
//   index: number;
//   onSelect: (i: number) => void;
//   label: (i: number) => string;
//   colorFor?: (i: number) => string;
// }) {
//   return (
//     <Stack direction="row" gap={0.4} sx={{ width: "100%" }}>
//       {Array.from({ length: total }, (_, i) => (
//         <Box
//           key={i}
//           component="button"
//           type="button"
//           aria-label={label(i)}
//           aria-current={i === index ? "step" : undefined}
//           onClick={() => onSelect(i)}
//           sx={{
//             flex: 1,
//             height: 6,
//             p: 0,
//             border: 0,
//             borderRadius: RADIUS.pill,
//             cursor: "pointer",
//             bgcolor: i <= index ? colorFor?.(i) ?? "primary.main" : "action.hover",
//             opacity: i < index ? 0.55 : 1,
//             outline: i === index ? "2px solid" : "none",
//             outlineColor: "text.primary",
//             outlineOffset: 2,
//             "&:focus-visible": { outline: "2px solid", outlineColor: "text.primary", outlineOffset: 2 },
//             "&:hover": { opacity: i === index ? 1 : 0.8 },
//           }}
//         />
//       ))}
//     </Stack>
//   );
// }

// export function Panel({ children }: { children: ReactNode }) {
//   return (
//     <Paper variant="outlined" sx={cardSx}>
//       {children}
//     </Paper>
//   );
// }


// export function StepCard({
//   stepText,
//   badge,
//   title,
//   children,
//   accent,
// }: {
//   stepText: string;
//   badge?: ReactNode;
//   title: string;
//   children: ReactNode;
//   accent?: string;
// }) {
//   return (
//     <Paper variant="outlined" sx={accentCardSx(accent)}>
//       <Stack direction="row" justifyContent="space-between" alignItems="center" gap={1} sx={{ mb: 0.8 }}>
//         <Typography variant="caption" sx={{ color: "primary.main", fontWeight: 800, letterSpacing: 0.8, textTransform: "uppercase" }}>
//           {stepText}
//         </Typography>
//         {badge && (
//           <Chip label={badge} size="small" sx={{ bgcolor: "action.selected", color: "primary.main", fontWeight: 800, maxWidth: "65%" }} />
//         )}
//       </Stack>
//       <Typography component="h2" variant="h2" sx={{ mb: 0.8 }}>
//         {title}
//       </Typography>
//       {children}
//     </Paper>
//   );
// }


// export function Callout({
//   label,
//   tone = "primary",
//   children,
// }: {
//   label: string;
//   tone?: "primary" | "secondary" | "info" | "warning" | "success";
//   children: ReactNode;
// }) {
//   return (
//     <Box
//       sx={{
//         p: 1,
//         borderRadius: RADIUS.inner,
//         bgcolor: (t) => alpha(t.palette[tone].main, 0.08),
//         borderLeft: "3px solid",
//         borderLeftColor: `${tone}.main`,
//       }}
//     >
//       <Typography variant="body2" sx={{ fontWeight: 800, color: `${tone}.main`, mb: 0.2 }}>
//         {label}
//       </Typography>
//       <Typography variant="body2" sx={{ lineHeight: 1.6 }}>
//         {children}
//       </Typography>
//     </Box>
//   );
// }


// export function StepNav({
//   index,
//   last,
//   onPrev,
//   onNext,
//   onRestart,
//   labels,
// }: {
//   index: number;
//   last: number;
//   onPrev: () => void;
//   onNext: () => void;
//   onRestart: () => void;
//   labels: { previous: string; restart: string; next: string };
// }) {
//   return (
//     <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1} sx={{ width: "100%" }}>
//       <Button variant="outlined" size="small" startIcon={<ArrowBackRoundedIcon />} disabled={index === 0} onClick={onPrev}>
//         {labels.previous}
//       </Button>
//       <Button variant="text" size="small" color="inherit" startIcon={<ReplayRoundedIcon />} onClick={onRestart}>
//         {labels.restart}
//       </Button>
//       <Button variant="contained" size="small" endIcon={<ArrowForwardRoundedIcon />} disabled={index === last} onClick={onNext}>
//         {labels.next}
//       </Button>
//     </Stack>
//   );
// }
/**
 * lessonKit.tsx – ONE place for the look of every lesson.
 *
 * Change a value here and all lessons update together.
 * Font sizes come from theme.ts (h1…caption); nothing here hardcodes px font sizes.
 *
 * Location: src/shared/lessonKit.tsx
 * Import:   import { … } from "../../../shared/lessonKit";
 */

import type { ReactNode } from "react";
import { alpha } from "@mui/material/styles";
import { Box, Button, Chip, Paper, Stack, Typography } from "@mui/material";

import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import ArrowBackRoundedIcon from "@mui/icons-material/ArrowBackRounded";
import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";



export const MONO = "ui-monospace, SFMono-Regular, Menlo, monospace";

export const RADIUS = { card: "22px", inner: "12px", pill: 99 } as const;


export const LESSON_ZOOM = 1;


export const PAGE_MAX_WIDTH = 1600;


export const cardSx = {
  p: { xs: 1.25, sm: 1.75 },
  borderRadius: RADIUS.card,
  borderColor: "divider",
  bgcolor: "background.paper",
} as const;

export const accentCardSx = (color = "primary.main") =>
  ({ ...cardSx, borderTop: "3px solid", borderTopColor: color }) as const;


export const insetSx = {
  p: 1,
  borderRadius: RADIUS.inner,
  bgcolor: "action.hover",
} as const;


export const nodeSx = (borderColor = "divider", bgcolor = "background.paper") =>
  ({
    p: 0.9,
    borderRadius: RADIUS.inner,
    border: "1.5px solid",
    borderColor,
    bgcolor,
    textAlign: "center",
  }) as const;

export const labelSx = {
  typography: "caption",
  fontWeight: 700,
  color: "text.secondary",
  textTransform: "uppercase",
  letterSpacing: 0.6,
} as const;


export const monoSx = { fontFamily: MONO, fontWeight: 700 } as const;



export function LessonPage({ children }: { children: ReactNode }) {
  return (
    <Stack
      spacing={1.5}
      sx={{
        width: "100%",
        maxWidth: PAGE_MAX_WIDTH / LESSON_ZOOM,
        mx: "auto",
        zoom: LESSON_ZOOM,
      }}
    >
      {children}
    </Stack>
  );
}

export function LessonBody({
  visual,
  children,
}: {
  visual: ReactNode;
  children: ReactNode;
}) {
  return (
    <Box
      sx={{
        display: "grid",
        gap: 1.5,
        alignItems: "start",
        gridTemplateColumns: { xs: "minmax(0, 1fr)", lg: "minmax(0, 1.05fr) minmax(0, 1fr)" },
      }}
    >
      <Box sx={{ minWidth: 0 }}>{visual}</Box>
      <Box sx={{ minWidth: 0 }}>{children}</Box>
    </Box>
  );
}

export function LessonHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Box>
      {eyebrow && (
        <Typography variant="subtitle2" sx={{ color: "primary.main", mb: 0.2 }}>
          {eyebrow}
        </Typography>
      )}
      <Typography component="h1" variant="h1" sx={{ letterSpacing: "-0.3px", mb: 0.3 }}>
        {title}
      </Typography>
      <Typography variant="body1" sx={{ color: "text.secondary" }}>
        {subtitle}
      </Typography>
    </Box>
  );
}

export function LessonStatus({
  availableLabel,
  right,
}: {
  availableLabel: string;
  right?: ReactNode;
}) {
  return (
    <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1}>
      <Chip label={availableLabel} size="small" sx={{ bgcolor: "success.main", color: "#fff", fontWeight: 800 }} />
      {right && (
        <Typography variant="body2" sx={{ color: "text.secondary", fontWeight: 700 }}>
          {right}
        </Typography>
      )}
    </Stack>
  );
}

export function StepBar({
  total,
  index,
  onSelect,
  label,
  colorFor,
}: {
  total: number;
  index: number;
  onSelect: (i: number) => void;
  label: (i: number) => string;
  colorFor?: (i: number) => string;
}) {
  return (
    <Stack direction="row" gap={0.4} sx={{ width: "100%" }}>
      {Array.from({ length: total }, (_, i) => (
        <Box
          key={i}
          component="button"
          type="button"
          aria-label={label(i)}
          aria-current={i === index ? "step" : undefined}
          onClick={() => onSelect(i)}
          sx={{
            flex: 1,
            height: 6,
            p: 0,
            border: 0,
            borderRadius: RADIUS.pill,
            cursor: "pointer",
            bgcolor: i <= index ? colorFor?.(i) ?? "primary.main" : "action.hover",
            opacity: i < index ? 0.55 : 1,
            outline: i === index ? "2px solid" : "none",
            outlineColor: "text.primary",
            outlineOffset: 2,
            "&:focus-visible": { outline: "2px solid", outlineColor: "text.primary", outlineOffset: 2 },
            "&:hover": { opacity: i === index ? 1 : 0.8 },
          }}
        />
      ))}
    </Stack>
  );
}


export function Panel({ children }: { children: ReactNode }) {
  return (
    <Paper variant="outlined" sx={cardSx}>
      {children}
    </Paper>
  );
}


export function StepCard({
  stepText,
  badge,
  title,
  children,
  accent,
}: {
  stepText: string;
  badge?: ReactNode;
  title: string;
  children: ReactNode;
  accent?: string;
}) {
  return (
    <Paper variant="outlined" sx={accentCardSx(accent)}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" gap={1} sx={{ mb: 0.8 }}>
        <Typography variant="caption" sx={{ color: "primary.main", fontWeight: 800, letterSpacing: 0.8, textTransform: "uppercase" }}>
          {stepText}
        </Typography>
        {badge && (
          <Chip label={badge} size="small" sx={{ bgcolor: "action.selected", color: "primary.main", fontWeight: 800, maxWidth: "65%" }} />
        )}
      </Stack>
      <Typography component="h2" variant="h2" sx={{ mb: 0.8 }}>
        {title}
      </Typography>
      {children}
    </Paper>
  );
}


export function Callout({
  label,
  tone = "primary",
  children,
}: {
  label: string;
  tone?: "primary" | "secondary" | "info" | "warning" | "success";
  children: ReactNode;
}) {
  return (
    <Box
      sx={{
        p: 1,
        borderRadius: RADIUS.inner,
        bgcolor: (t) => alpha(t.palette[tone].main, 0.08),
        borderLeft: "3px solid",
        borderLeftColor: `${tone}.main`,
      }}
    >
      <Typography variant="body2" sx={{ fontWeight: 800, color: `${tone}.main`, mb: 0.2 }}>
        {label}
      </Typography>
      <Typography variant="body2" sx={{ lineHeight: 1.6 }}>
        {children}
      </Typography>
    </Box>
  );
}


export function StepNav({
  index,
  last,
  onPrev,
  onNext,
  onRestart,
  labels,
}: {
  index: number;
  last: number;
  onPrev: () => void;
  onNext: () => void;
  onRestart: () => void;
  labels: { previous: string; restart: string; next: string };
}) {
  return (
    <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1} sx={{ width: "100%" }}>
      <Button variant="outlined" size="small" startIcon={<ArrowBackRoundedIcon />} disabled={index === 0} onClick={onPrev}>
        {labels.previous}
      </Button>
      <Button variant="text" size="small" color="inherit" startIcon={<ReplayRoundedIcon />} onClick={onRestart}>
        {labels.restart}
      </Button>
      <Button variant="contained" size="small" endIcon={<ArrowForwardRoundedIcon />} disabled={index === last} onClick={onNext}>
        {labels.next}
      </Button>
    </Stack>
  );
}